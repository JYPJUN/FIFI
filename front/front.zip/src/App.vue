<template>
  <header>
    <nav>
      <RouterLink :to="{ name: 'HomeView' }">홈</RouterLink> |

      <RouterLink :to="{ name: 'ArticleView' }">Articles</RouterLink> |
      <RouterLink v-if="!store.isLoggin" :to="{ name: 'SignUpView' }">회원가입</RouterLink> |
      <RouterLink v-if="!store.isLoggin" :to="{ name: 'LogInView' }">로그인</RouterLink> |
      <RouterLink v-if="store.isLoggin" :to="{ name: 'HomeView' }" @click="logOut">로그아웃</RouterLink> |
      <RouterLink v-if="store.isLoggin" :to="{ name: 'ProfileView' }">프로필</RouterLink> |
      <RouterLink :to="{ name: 'KakaoView' }">Kakao</RouterLink> |

    </nav>
  </header>
  <div v-if="store.isLoggin">
    <h2>안녕하세요, {{ store.user }}</h2>
  </div>
  <div v-else>
    <h2>로그인이 필요합니다.</h2>
  </div>
  <RouterView />
</template>

<script setup>
import { RouterView, RouterLink } from 'vue-router'
import { useCustomerStore } from '@/stores/customer';
const store = useCustomerStore()

const logOut = function () {
  store.logOut()
}
</script>

<style scoped>
</style>
