<template>
  <div>
    <h3>Article List</h3>
    <ArticleListItem
    v-for="article in store.articles"
    :key="article.id"
    :article="article"/>
  </div>
</template>

<script setup>
import { useCustomerStore } from '@/stores/customer';
import ArticleListItem from './ArticleListItem.vue';

const store = useCustomerStore()
</script>

<style scoped>

</style>