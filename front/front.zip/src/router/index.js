import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '@/views/HomeView.vue'
import SignUpView from '@/views/SignUpView.vue'
import LogInView from '@/views/LogInView.vue'
import ArticleView from '@/views/ArticleView.vue'
import DetailView from '@/views/DetailView.vue'
import ProfileView from '@/views/ProfileView.vue'
import KakaoView from '@/views/KakaoView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path:'/',
      name:'HomeView',
      component: HomeView
    },
    {
      path:'/signup',
      name:'SignUpView',
      component: SignUpView
    },
    {
      path:'/login',
      name:'LogInView',
      component: LogInView
    },
    {
      path:'/articles',
      name:'ArticleView',
      component: ArticleView
    },
    {
      path:'/articles/:id',
      name:'DetailView',
      component: DetailView
    },
    {
      path:'/profile',
      name:'ProfileView',
      component: ProfileView
    },
    {
      path:'/kakao',
      name:'KakaoView',
      component: KakaoView
    },
  ]
})

import { useCustomerStore } from '@/stores/customer'

export default router
