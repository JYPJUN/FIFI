import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import axios from 'axios'
import { useRouter } from 'vue-router'

export const useCustomerStore = defineStore('customer', () => {
  const token = ref(null)
  const API_URL = 'http://127.0.0.1:8000'
  // 게시글 임시 데이터
  const articles = ref([
    {id:1, title:'Article 1',content:'Content of article 1'},
    {id:2, title:'Article 2',content:'Content of article 2'}
  ])
  const user = ref(null) // 유저 이름
  const userdetail = ref(null) // 유저 프로필용 디테일
  const router = useRouter()
  const isLoggin = computed(() => !!token.value ) // 로그인 여부 확인용


  // 회원가입 - 회원가입 시 자동 로그인 후 HomeVie로 이동
  const signUp = function (payload) {
    const { username, password1, password2, birth_date, email, name } = payload
    axios({
      method: 'post',
      url: `${API_URL}/accounts/signup/`,
      data: {
        username, password1, password2, birth_date, email, name
      }
    })
      .then((response) => {
        console.log('회원가입 성공!')
        const password = password1
        logIn({ username, password })
      })
      .catch(error => {
        console.log(error)
      })
  }

  // 로그인 - 로그인 시 HomeView로 이동
  const logIn = function(payload){
    const username = payload.username
    const password = payload.password
    axios({
      method: 'post',
      url: `${API_URL}/accounts/login/`,
      data: {
        username, password
      }
    })
    .then(response => {
      token.value = response.data.key
      // getProfile()
      user.value = payload.username
      router.push({ name : 'HomeView' })
    })
    .catch(error => console.log(error))
  }

  // 로그아웃 - 로그아웃 시 자동으로 HomeView로 이동 (이동은 App에서 구현함)
  const logOut = function () {
    axios({
      method: 'post',
      url : `${API_URL}/accounts/logout/`,
      headers : {
        Authorization: `Token ${token.value}`
      }
    })
    .then(response => {
      token.value = null
      user.value = null
      userdetail.value = null
    })
    .catch(error => console.log(error))
  }

  // 유저 프로필 정보 반환
  const getProfile = function () {
    return axios({
      method: 'get',
      url : `${API_URL}/accounts/user/`,
      headers : {
        Authorization : `Token ${token.value}`
      }
    })
    .then(response => {
      userdetail.value = response.data
    })
    .catch(error => {
      console.log(error)
    })
  }

  // Article
  const getArticles = function(){
    axios({
      method:'get',
      url:`${API_URL}/api/v1/articles/`
    })
    .then(response => {
      console.log(response.data)
      articles.value = response.data
    })
    .catch((error) => {console.log(error)})
  }


  return { articles, API_URL, signUp, logIn, logOut, token, isLoggin, user, getProfile, userdetail, getArticles}

},{persist:true})
