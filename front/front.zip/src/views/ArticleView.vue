<template>
  <div>
    <h1>커뮤니티</h1>
    <h1>박선민바보 </h1>
    <ArticleList />
  </div>
</template>

<script setup>
import {onMounted} from 'vue'
import { useCustomerStore } from '@/stores/customer'
import ArticleList from '@/components/ArticleList.vue'

const store = useCustomerStore()
onMounted(()=>{
  store.getArticles()
})

</script>

<style scoped>

</style>