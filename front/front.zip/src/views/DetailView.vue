<template>
  <div>
    <h1>상세 페이지</h1>
    <div v-if="article">
      <p>글 번호 : {{ article.id }}</p>
      <p>제목 : {{ article.title }}</p>
      <p>내용 : {{ article.content }}</p>
      <p>작성시간 : {{ article.created_at }}</p>
    </div>
  </div>
</template>

<script setup>
import axios from 'axios'
import { onMounted,ref } from 'vue'
import { useRoute } from 'vue-router'
import { useCustomerStore } from '@/stores/customer'

const store = useCustomerStore()
const route = useRoute()
const article = ref(null)

onMounted(()=>{
  axios({
    method:'get',
    url:`${store.API_URL}/api/v1/articles/${route.params.id}/`
  })
  .then((response)=>{
    console.log(response.data)
    article.value = response.data
  })
  .catch((error) => {console.log(error)})
})
</script>

<style scoped>

</style>
