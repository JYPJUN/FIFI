<template>
  <div>
    <h1>안녕하세요 HOME 화면입니다</h1>
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>