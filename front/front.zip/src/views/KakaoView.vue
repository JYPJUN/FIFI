<template>
  <div>
      <h2>KakaoView</h2>
      <KakaoMap />
  </div>
</template>

<script setup>
import KakaoMap from '@/components/KakaoMap.vue';


</script>

<style scoped>

</style>