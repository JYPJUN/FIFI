<template>
  <div>
    <div v-if="detail">
    <p> pk값 : {{ detail.pk }}</p>
    <p> 유저 아이디 : {{ detail.username }}</p>
    <p> 유저 이름 : {{ detail.name }}</p>
    <p> 이메일 : {{ detail.email }}</p>
    <p> pk값 : {{ detail.birth_date }}</p>

    <p>{{ detail }}</p>
  </div>
  </div>

  <h1>왜 회원가입하거나 로그인했을 때 여기로 오면 바로 프로필이 뜨지 않고 나갔다가 다시 들어와야 생김??</h1>
</template>

<script setup>
import { useCustomerStore } from '@/stores/customer'
import { onMounted, ref } from 'vue'

const store = useCustomerStore()
const detail = ref(null)
onMounted(() => {
  store.getProfile().then(()=> {
    detail.value = store.userdetail
  })
})


</script>

<style scoped>

</style>