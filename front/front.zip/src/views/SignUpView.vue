<template>
    <div>
        <h1>회원가입</h1>
        <form @submit.prevent="signUp">
            <label for="username">아이디 : </label>
            <input type="text" id="username" v-model.trim="username" required /><br>

            <label for="password1">비밀번호 : </label>
            <input type="password" id="password1" v-model.trim="password1" required /><br>

            <label for="password2">비밀번호 확인 : </label>
            <input type="password" id="password2" v-model.trim="password2" required /><br>

            <label for="name">이름:</label>
            <input type="text" id="name" v-model="name" required />

            <label for="birth_date">Birth Date:</label>
            <input type="date" id="birth_date" v-model="birth_date" required />

            <label for="email">email:</label>
            <input type="email" id="email" v-model="email" required />

            <input type="submit" value="SignUp">
        </form>
    </div>
</template>

<script setup>
import { ref } from 'vue'
import { useCustomerStore } from '@/stores/customer'

const username = ref(null) 
const password1 = ref(null)
const password2 = ref(null)
const birth_date = ref(null)
const email = ref(null)
const name = ref(null)
const store = useCustomerStore()

const signUp = function () {
  const payload = {
    username: username.value,
    password1: password1.value,
    password2: password2.value,
    birth_date: birth_date.value,
    email: email.value,
    name: name.value,
  }
  store.signUp(payload)
}
</script>

<style scoped>

</style>